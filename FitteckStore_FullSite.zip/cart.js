// Simple front-end cart (stores in localStorage)
const CART_KEY = 'fitteck_cart_v1';
function getCart(){ try{ return JSON.parse(localStorage.getItem(CART_KEY))||[] }catch(e){return[]} }
function saveCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)); updateCartCount(); }
function updateCartCount(){ const c = getCart(); document.getElementById('cart-count')?.innerText = c.length; }
function addToCart(product){ const c=getCart(); c.push(product); saveCart(c); alert('Added to cart'); }
function clearCart(){ localStorage.removeItem(CART_KEY); updateCartCount(); alert('Cart cleared') }
updateCartCount();
